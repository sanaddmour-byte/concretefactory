THE CONCRETE FACTORY: finish naming pack
=========================================

What this is
  Photos that need a pattern name and a colour name before they go into the
  Finish Library. Each photo is numbered; names-sheet.csv has one row per photo.

What to send back
  For each numbered photo (any format: fill the CSV, or just reply in a message):
    - Pattern name, English and Arabic   (e.g. "Fan cobblestone", "Ashlar slate")
    - Colour name, English and Arabic    (e.g. "Charcoal", "Terracotta")
    - Your finish code, if you already use one (otherwise we will propose codes)
    - Optional notes: method (stamped / terrazzo / exposed aggregate), sealer
      (matte / gloss), indoor or outdoor, best uses.

Please confirm these specifically
  - The cyan aggregate photo: is the cyan aggregate a coloured glass, or glow-in-the-dark stone?
    (We will not claim a glow until you confirm it.)
  - Photo with the saw-cut joint (finish-tan-sawcut): what finish is it
    (microtopping, stained concrete, other)?
  - The concentric-circles photo: is the green-grey tone the pigment or weathering?

Rules we follow
  - Names are shown exactly as you write them. We never invent names or colours.
  - Photos keep their true colour: no filters.
  - Photos marked "optional (pattern only)" are installed-floor shots; a pattern
    name is enough.
